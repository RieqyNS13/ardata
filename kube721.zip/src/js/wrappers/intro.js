/*
	Kube UI Framework
	Version 7.2.1
	Updated: November 10, 2018

	http://imperavi.com/kube/

	Copyright (c) 2009-2018, Imperavi LLC.
	License: MIT
*/
(function() {